// Code moved to inlines.js, this file left for backwards compatibility imports
