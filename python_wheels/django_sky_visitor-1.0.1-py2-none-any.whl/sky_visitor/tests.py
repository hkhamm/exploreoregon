# Copyright 2013 Concentric Sky, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from django.test import TestCase


class SkyVisitorTestCase(TestCase):

    def assertLoggedIn(self, user, backend=None):
        self.assertEqual(self.client.session['_auth_user_id'], user.id)
        if backend:
            self.assertEqual(self.client.session['_auth_user_backend'], backend)

    def assertRedirected(self, response, expected_url, status_code=302):
        self.assertEqual(response.status_code, status_code)
        self.assertEqual(response._headers['location'][1], 'http://testserver%s' % expected_url)
