A Django application to use CKEditor for textareas.


